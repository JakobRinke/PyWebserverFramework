

DIR="$(cd "$(dirname "$0")" && pwd)"


echo $DIR"/main.py"

python3 "$DIR""/__main__.py"


    


